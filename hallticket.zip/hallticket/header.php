<?php

    $server = 'localhost';
    $username = 'jeevithaa';
    $password = 'Gvta_2003';
    $dbname = 'univ';

    $conn = mysqli_connect($server, $username, $password, $dbname);
?>